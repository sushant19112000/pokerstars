import RebatePage from "@/app/components/pokerstars/200rebatePage";
import Bonus100Page from "@/app/components/pokerstars/bonus100Page";
import MultiSportsPage from "@/app/components/pokerstars/multi-SportPage";

export default function Index() {
  return (
    <div>
      {/* <Main/> */}

      <Bonus100Page />
      {/* <MultiSportsPage/> */}
      {/* <RebatePage/> */}
    </div>
  );
}
