"use client";


import Head from "next/head";

export default function Home() {
  return (
    <>
      <Head>
        <title>Martechavenue</title>
      </Head>
      <div style={{ backgroundColor: '' }}>
        <div className="" style={{ backgroundColor: '' }}>
          Home
        </div>
      </div>

    </>
  )
}
