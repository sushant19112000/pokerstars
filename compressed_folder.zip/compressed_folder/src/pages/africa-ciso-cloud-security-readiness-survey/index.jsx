import { Main } from "@/app/components/survey/main";

export default function Index(){
    return (
      <Main/>  
    )
}