import { Main } from "@/app/components/gitexSurvey/main";
import React from "react";

const Index = () => {
  return (
    <div>
      <Main />
    </div>
  );
};

export default Index;
