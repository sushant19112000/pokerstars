import { Main } from "@/app/components/pokerstars/main";
import { page2 } from "@/app/components/pokerstars/page2";

export default function Index(){
  return (
     <>
     <div dangerouslySetInnerHTML={{__html:page2}}>

     </div>
     
     </>
  )
}


