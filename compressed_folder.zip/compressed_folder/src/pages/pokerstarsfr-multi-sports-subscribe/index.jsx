import { Main } from "@/app/components/pokerstars/main";

export default function Index(){
    return (
        <>

        <Main></Main>
        
        </>
    )
}