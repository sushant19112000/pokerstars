// atoms/asset.js

import { atom } from "recoil";



export const GitexSurvey2024StateTab = atom({
  key: "gitexSurvey2024StateTab", // unique ID (with respect to other atoms/selectors)
  default: 1, // default value (aka initial value)
//   effects_UNSTABLE:[persistAtom]
});
