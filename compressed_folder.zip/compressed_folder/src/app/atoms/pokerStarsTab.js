// atoms/asset.js
import { atom } from "recoil";
export const pokerStarsTab = atom({
  key: "pokerStarsTab", // unique ID (with respect to other atoms/selectors)
  default: 1, // default value (aka initial value)
//   effects_UNSTABLE:[persistAtom]
});



