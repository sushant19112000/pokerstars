export default function Heading() {
  return (
    <main className="py-5" style={{ backgroundColor: "black", color: "White" }}>
      <div className="container ">
        <h1 className="mb-4" style={{ fontWeight: "900" }}>
          À PROPOS DE L’OFFRE
        </h1>
        <p>
          Rejoignez PokerStars. Déposez 10 € ou plus en utilisant le code «
          STARS100 » et profitez de votre bonus pouvant aller jusqu’à 100 €.
          C'est aussi simple que ça. Lisez la suite pour en savoir plus.
        </p>
      </div>
    </main>
  );
}
