import React from 'react'
export const Grid = () => {
    return (
        <div className='row justify-content-center'>
            <div className="col-md-4 mb-2">
                <picture>
                    <img className='img-fluid' alt="" />
                </picture>
            </div>
            <div className="col-md-4 mb-2">
                <picture>
                    <img className='img-fluid' alt="" />
                </picture>
            </div>
            <div className="col-md-4 mb-2">
                <picture>
                    <img className='img-fluid' alt="" />
                </picture>
            </div>
        </div>
    )
}

