import React from 'react'

export const Mainpage2 = () => {
  return (
    <div ></div>
  )
}
