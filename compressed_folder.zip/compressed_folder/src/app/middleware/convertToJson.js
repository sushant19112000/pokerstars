export const convertToJson=(stringData)=>{
    const jsonData = JSON.parse(stringData);

    return jsonData

}
