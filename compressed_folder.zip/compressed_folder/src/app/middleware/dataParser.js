import {convertToJson} from "@/app/middleware/convertToJson"

export const dataParser=(blog)=>{
    return convertToJson(blog)
}




