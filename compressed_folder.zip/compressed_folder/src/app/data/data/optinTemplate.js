export const optinTemplate = `<div style="display: flex; align-items: center; font-size: 16px; color: #000000;">
    <input style="width: fit-content; margin: revert; padding-top: 2px;" type="checkbox" name="authorize_check_me" required="" id="email-me-check">
    <p style="margin-left: 10px; font-size: 16px; color: #000000; letter-spacing: normal; word-spacing: normal; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', 'Liberation Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';">
        Your text here
    </p>
</div>`;
