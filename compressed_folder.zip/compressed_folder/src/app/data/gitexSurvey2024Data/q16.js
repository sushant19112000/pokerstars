export const q16 = {
    questionNumber:17,
    gridType:'row',
  optionSelectType: 'double',
  question: "*What are the priority areas for automation?",
  answers: [
    "Security",
    "Customer experience",
    "HR and employee experience ",
    "Accounting and finance",
    "Data processing ",
    "Sales and marketing",
    "IT (development) ",
    "Product",
    "Other (Please state)",
  ],
};
