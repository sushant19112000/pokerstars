export const q11 = {
    questionNumber:12,
  gridType:'col',
  optionSelectType: 'single',
  question:
    "*How confident are you that your current security measures are strong enough when implementing new IT projects?",
  answers: ["Very confident", "Confident", "Not confident", "I don't know"],
};
