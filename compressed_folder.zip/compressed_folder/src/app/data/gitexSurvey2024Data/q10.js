export const q10 = {
    questionNumber:11,
    gridType:'col',
    optionSelectType: 'single',
    question:
        "*How confident are you that your organisation is protected from attacks?",
    answers: [
        "Very Confident",
        "Confident ",
        "Not confindent",
        "I don't know"
    ],
};
