export const q12 = {
    questionNumber:13,
    gridType:'row',
    optionSelectType: 'single',
  question:
    "*Which security areas are priorities for your organisation in the year ahead?",
  answers: [
    "cloud",
    "Network",
    "Application ",
    "Email",
    "Operational technology and IIot",
    "Threat hunting",
    "Penetration testing ",
    "Data security",
    "Security culture and staff training",
    "Compliance and regulation",
    "Evolving technological landscape/increasing sophistication ",
  ],
};
