export const q9 = {
    questionNumber:10,
    gridType:'row',
    optionSelectType:'single',
    question: "*Has your organisation seen a change in the number of attacks over the last 12 months?",
    answers: [
        "Yes- a significant increase",
        "Yes- a slight increase",
        "No - it has remained the same",
        "No - there has been a decrease",
        "I dont know"
    ]
};



