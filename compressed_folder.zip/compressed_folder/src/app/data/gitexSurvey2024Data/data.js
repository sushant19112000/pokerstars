import { q2 } from "./q2";
import { q3 } from "./q3";
import { q4 } from "./q4";
import { q5 } from "./q5";
import { q6 } from "./q6";
import { q7 } from "./q7";
import { q8 } from "./q8";
import { q9 } from "./q9";
import { q10 } from "./q10";
import { q11 } from "./q11";
import { q12 } from "./q12";
import { q13 } from "./q13";
import { q14 } from "./q14";
import { q15 } from "./q15";
import { q16 } from "./q16";
import { q17 } from "./q17";
import { termAndCondition } from "./termsAndConditon";

export const questionsData = [
  q2,
  q3,
  q4,
  q5,
  q6,
  q7,
  q8,
  q9,
  q10,
  q11,
  q12,
  q13,
  q14,
  q15,
  q16,
  q17,
];
export const termsAndConditionAnswers = termAndCondition;
