export const q13 = {
    questionNumber:14,
    gridType:'col',
  optionSelectType: 'single',
  question: "*Does your organisation have a strong security culture?",
  answers: ["Yes", "No", "I don't know "],
};
