export const q3 = {
    questionNumber:4,
    gridType:'row',
    optionSelectType:'single',
    question: "*Has your organisation increased investment in Digital Transformation projects in the last 12 months?",
    answers: [
      "Yes-significantly",
      "Yes-slightly",
      "Yes-moderately",
      "No",
      "I don't know",
      "We are not planning any digitalisation initaives"
    ]
};
  