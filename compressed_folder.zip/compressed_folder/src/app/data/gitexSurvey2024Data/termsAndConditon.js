export const termAndCondition={
    questionNumber:19,
    gridType:'row',
    optionSelectType: 'single',
    answers:[
      "Yes, I agree to these terms",
      "No, I don't agree to these terms"
    ]
}


  