export const q8 = {
    questionNumber:9,
    gridType:'row',
    optionSelectType:'double',
    question: "*What are the most important considerations for you when selecting an infrastructure partner?",
    answers: [
        "Security",
        "Cost",
        "Reputation[TRACK RECORD]",
        "Location [IN-COUNTRY]",
        "Vendor certifications",
        "Technology skills",
        "Number of skilled resources",
        "Other (Please state)"
    ]
};
