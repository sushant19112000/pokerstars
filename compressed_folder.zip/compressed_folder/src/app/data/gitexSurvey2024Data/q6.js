export const q6 = {
    questionNumber:7,
    gridType:'col',
    optionSelectType:'single',
    question: "*Which of the following best describes your long-term plans for infrastructure?",
    answers: [
      "On-premises",
      "Hybrid",
      "All-in cloud",
      "Multi-cloud",
    ]
};

