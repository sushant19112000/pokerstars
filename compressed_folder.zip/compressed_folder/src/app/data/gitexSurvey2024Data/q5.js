export const q5 = {
    questionNumber:6,
    gridType:'col',
    optionSelectType:'single',
    question: "*Which of the following best describes your current infrastructure model?",
    answers: [
      "Legacy",
      "Onsite client server",
      "Private cloud",
      "Public cloud",
      "Multi cloud",
      "Hybrid cloud",
    ]
};


