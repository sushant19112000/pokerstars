export const q4 = {
    questionNumber:5,
    gridType:'row',
    optionSelectType:'double',
    question: "*Which of the following are most important to you in your digitalisation journey?",
    answers: [
      "Cost-savings",
      "Address technical skills shortages within the orgainsation",
      "Faster time to market",
      "Employee productivity",
      "Automation",
      "Offer better customer experiences",
      "Increased agility",
      "Greater security"
    ]
};


  