export const q15 = {
    questionNumber:16,
    gridType:'col',
    optionSelectType: 'single',
    question:
        "*How far do you believe automation will enable you to achieve your long-term business goals?",
    answers: [
        "Strongly agree",
        "Agree",
        "I don't know  ",
        "Disagree",
        "Strongly disagree",
    ],
};
