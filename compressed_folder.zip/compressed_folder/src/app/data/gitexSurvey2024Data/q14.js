export const q14 = {
    questionNumber:15,
    gridType:'row',
  optionSelectType: 'single',
  question:
    "*How would you describe your organisation’s readiness to deploy automation solutions?",
  answers: [
    "We have not yet deployed AI solutions but are preparing to",
    "We are in the process of deploying AI solutions",
    "We do not plan to deploy AI solutions ",
    "I don’t know",
  ],
};
