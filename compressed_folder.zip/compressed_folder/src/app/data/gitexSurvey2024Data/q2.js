export const q2 = {
    questionNumber:3,
    gridType:'col',
    optionSelectType:'single',
    question: "*What size company are you from?",
    answers: [
      "250-500",
      "500-1000",
      "1000-1500",
      "1500+",
    ]
};
  