-- CreateTable
CREATE TABLE "africaSurvery" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "data" TEXT NOT NULL
);
